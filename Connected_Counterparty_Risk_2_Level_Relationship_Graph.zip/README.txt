Open index.html in Edge or Chrome. Relationship Graph now supports Level 1 and Level 2 connected counterparties. The Alpha Urban Holdings example includes Alpha -> Delta Real Estate -> Apex Trading.
