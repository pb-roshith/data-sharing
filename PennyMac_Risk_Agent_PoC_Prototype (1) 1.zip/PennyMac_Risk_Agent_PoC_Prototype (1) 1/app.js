/* PennyMac Capital Markets Risk Agent PoC — application logic (v2: live Copilot agent) */
(function () {
  'use strict';

  var D = window.POC_DATA || [];
  var DICT = window.POC_DICTIONARY || [];
  var META = window.POC_META || {};
  var F = D.slice(); // sidebar-filtered set
  var TAB = 'copilot';
  var nf = new Intl.NumberFormat('en-US');
  var renderToken = 0; // guards against out-of-order async renders

  // Configurable at runtime (e.g. from devtools) or via window global before app.js loads.
  // Relative path works automatically when served by server.py (same-origin).
  // When index.html is opened directly as a file:// page, this fetch will fail fast
  // and the UI gracefully falls back to the built-in local analyst engine.
  var COPILOT_ENDPOINT = window.PENNYMAC_COPILOT_ENDPOINT || '/api/copilot';
  var COPILOT_TIMEOUT_MS = 12000;

  var TABS = [
    { id: 'copilot', label: 'Risk Copilot Report' },
    { id: 'exec', label: 'Executive Dashboard' },
    { id: 'market', label: 'Market Risk (DV01/PV01/KRD)' },
    { id: 'prepay', label: 'Prepayment & MSR' },
    { id: 'funding', label: 'Funding & Liquidity' },
    { id: 'servicing', label: 'Production & Servicing' },
    { id: 'dictionary', label: 'Data Dictionary' }
  ];

  // ---------- formatting helpers ----------
  function money(v) {
    v = Number(v) || 0;
    var abs = Math.abs(v);
    var s;
    if (abs >= 1e9) s = '$' + (v / 1e9).toFixed(2) + 'B';
    else if (abs >= 1e6) s = '$' + (v / 1e6).toFixed(2) + 'M';
    else if (abs >= 1e3) s = '$' + (v / 1e3).toFixed(1) + 'K';
    else s = '$' + v.toFixed(0);
    return v < 0 ? '(' + s.replace('-', '') + ')' : s;
  }
  function pct(v) { return ((Number(v) || 0) * 100).toFixed(1) + '%'; }
  function num(v, d) { d = d || 0; return nf.format(Number((Number(v) || 0).toFixed(d))); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  // ---------- aggregation helpers ----------
  function sum(arr, field) { var t = 0; for (var i = 0; i < arr.length; i++) t += Number(arr[i][field]) || 0; return t; }
  function avg(arr, field) { return arr.length ? sum(arr, field) / arr.length : 0; }
  function uniq(field) {
    var set = {};
    for (var i = 0; i < D.length; i++) { var v = D[i][field]; if (v) set[v] = true; }
    return Object.keys(set).sort();
  }
  function groupAgg(arr, key, field, mode) {
    mode = mode || 'sum';
    var m = {};
    for (var i = 0; i < arr.length; i++) {
      var k = arr[i][key] || 'Unassigned';
      if (!m[k]) m[k] = [0, 0];
      m[k][0] += Number(arr[i][field]) || 0;
      m[k][1] += 1;
    }
    var out = [];
    for (var key2 in m) out.push([key2, mode === 'avg' ? m[key2][0] / m[key2][1] : m[key2][0], m[key2][1]]);
    out.sort(function (a, b) { return Math.abs(b[1]) - Math.abs(a[1]); });
    return out;
  }
  function monthlyAgg(arr, field, mode) {
    mode = mode || 'sum';
    var m = {};
    for (var i = 0; i < arr.length; i++) {
      var k = (arr[i].as_of_date || '').slice(0, 7) || 'NA';
      if (!m[k]) m[k] = [0, 0];
      m[k][0] += Number(arr[i][field]) || 0;
      m[k][1] += 1;
    }
    var keys = Object.keys(m).sort();
    keys = keys.slice(Math.max(0, keys.length - 18));
    return keys.map(function (k) { return [k, mode === 'avg' ? m[k][0] / m[k][1] : m[k][0]]; });
  }

  // ================================================================
  // INTENT PARSER — this is what makes the report question-aware.
  // Deterministic, transparent, and testable: it extracts entities,
  // a risk "focus area", threshold filters, top-N limits and a sort
  // metric directly from the free-text question, BEFORE any chart or
  // number is computed. This is the same "retrieval/grounding" step
  // that any serious LLM-backed agent needs — it keeps the numbers
  // trustworthy even when an LLM later writes the prose around them.
  // ================================================================
  var AGENCY_PATTERNS = [
    { re: /ginnie|gnma/i, agency: 'Ginnie Mae' },
    { re: /fannie/i, agency: 'Fannie Mae' },
    { re: /freddie/i, agency: 'Freddie Mac' },
    { re: /\bpmt\b/i, agency: 'PMT / Conventional' },
    { re: /non[- ]?agency|private investor/i, agency: 'Private Investor / Non-Agency' }
  ];
  var PRODUCT_PATTERNS = [
    { re: /\bfha\b/i, product: 'FHA' },
    { re: /\bva\b(?!lley)/i, product: 'VA' },
    { re: /\busda\b/i, product: 'USDA' },
    { re: /jumbo/i, product: 'Jumbo / Non-Agency' },
    { re: /conventional|conforming/i, product: 'Conventional Conforming' }
  ];
  var COMPONENT_PATTERNS = [
    { re: /\bmsr\b|servicing right/i, component: 'Owned MSR servicing' },
    { re: /correspondent/i, component: 'Correspondent production' },
    { re: /broker/i, component: 'Broker direct lending' },
    { re: /consumer direct/i, component: 'Consumer direct lending' },
    { re: /subservic/i, component: 'Subservicing / PMT / non-affiliates' },
    { re: /early buyout|\bebo\b/i, component: 'Early buyout / distressed servicing' },
    { re: /pmt relationship/i, component: 'PMT relationship' }
  ];
  var FOCUS_KEYWORDS = {
    market: /\bdv01|pv01|krd|key rate|duration|hedge(?!d loan)|rate risk|yield curve|curve risk|basis point/i,
    prepay: /\bcpr\b|\bpsa\b|prepay|runoff|refinance incentive|refi incentive|burnout|speed/i,
    funding: /warehouse|liquidity|margin call|funding|repo|haircut/i,
    servicing: /delinquen|repurchase|defect|production volume|servicing status|loss mitigation|foreclosure/i
  };

  function parseIntent(question) {
    var q = (question || '').trim();
    var lower = q.toLowerCase();

    var intent = {
      raw: q,
      hasQuestion: q.length > 0,
      agency: null,
      product: null,
      component: null,
      focus: 'overview',
      thresholds: [], // { field, op, value }
      topN: null,
      sortField: null
    };

    AGENCY_PATTERNS.some(function (p) { if (p.re.test(q)) { intent.agency = p.agency; return true; } return false; });
    PRODUCT_PATTERNS.some(function (p) { if (p.re.test(q)) { intent.product = p.product; return true; } return false; });
    COMPONENT_PATTERNS.some(function (p) { if (p.re.test(q)) { intent.component = p.component; return true; } return false; });

    // Focus area: score each bucket by number of keyword matches, pick the highest (ties -> priority order below)
    var scores = { market: 0, prepay: 0, funding: 0, servicing: 0 };
    Object.keys(FOCUS_KEYWORDS).forEach(function (k) {
      var m = lower.match(FOCUS_KEYWORDS[k]);
      scores[k] = m ? m.length : 0;
    });
    var priority = ['market', 'prepay', 'funding', 'servicing'];
    var best = 'overview', bestScore = 0;
    priority.forEach(function (k) { if (scores[k] > bestScore) { bestScore = scores[k]; best = k; } });
    intent.focus = best;

    // Threshold phrases like "cpr gap above 2%", "warehouse utilization over 85%", "dv01 utilization > 70%"
    var thresholdRe = /(cpr gap|cpr|warehouse|utilization|dv01|prepay01|prepay)?\s*(?:above|over|greater than|exceeding|>\s*)\s*(\d+(?:\.\d+)?)\s*%?/gi;
    var m2;
    while ((m2 = thresholdRe.exec(lower))) {
      var label = (m2[1] || '').toLowerCase();
      var value = parseFloat(m2[2]);
      if (value > 1) value = value / 100; // interpret "85" as 85% -> 0.85
      var field = null;
      if (label.indexOf('cpr') !== -1) field = 'cpr_gap_pct';
      else if (label.indexOf('warehouse') !== -1 || label.indexOf('utilization') !== -1) field = 'warehouse_utilization_pct';
      else if (label.indexOf('dv01') !== -1) field = 'dv01_limit_utilization_pct';
      else if (label.indexOf('prepay') !== -1) field = 'prepay_utilization_pct';
      if (field) intent.thresholds.push({ field: field, op: '>=', value: value });
    }

    // Top-N: "top 10", "top 5 records"
    var topMatch = lower.match(/top\s+(\d{1,3})/);
    if (topMatch) intent.topN = parseInt(topMatch[1], 10);

    // Sort/emphasis metric
    if (/prepay01/i.test(q)) intent.sortField = 'prepay01_usd';
    else if (/dv01/i.test(q)) intent.sortField = 'net_dv01_after_hedge';
    else if (/msr value/i.test(q)) intent.sortField = 'msr_value_usd';
    else intent.sortField = 'current_upb_usd';

    return intent;
  }

  // Apply the parsed intent as an ADDITIONAL narrowing on top of the sidebar filters (F).
  function applyIntentScope(baseArr, intent) {
    var out = baseArr.filter(function (o) {
      if (intent.agency && o.agency_investor !== intent.agency) return false;
      if (intent.product && o.product_type !== intent.product) return false;
      if (intent.component && o.portfolio_component !== intent.component) return false;
      for (var i = 0; i < intent.thresholds.length; i++) {
        var t = intent.thresholds[i];
        if (!(Number(o[t.field]) >= t.value)) return false;
      }
      return true;
    });
    // If the intent filters produced an empty set (e.g. contradictory question), fall back to
    // the sidebar-filtered population so the report is never blank — but flag it in the result.
    var wasNarrowed = out.length !== baseArr.length;
    var emptyFallback = false;
    if (out.length === 0) { out = baseArr; emptyFallback = true; }
    return { data: out, narrowed: wasNarrowed, emptyFallback: emptyFallback };
  }

  // ---------- SVG chart builders ----------
  function svgBars(data, opts) {
    opts = opts || {};
    var w = 720, h = 260, pad = 46;
    var maxV = 1;
    data.forEach(function (d) { maxV = Math.max(maxV, Math.abs(d[1])); });
    var bw = (w - 2 * pad) / Math.max(data.length, 1);
    var mid = h / 2;
    var bars = '';
    data.forEach(function (d, i) {
      var v = Number(d[1]) || 0;
      var x = pad + i * bw + 4;
      var bh = (Math.abs(v) / maxV) * (h / 2 - 24);
      var y = v >= 0 ? mid - bh : mid;
      var color = v >= 0 ? '#1f5eff' : '#d92d20';
      var label = String(d[0]).length > 16 ? String(d[0]).slice(0, 15) + '…' : String(d[0]);
      var valTxt = opts.money ? money(v) : (opts.pct ? pct(v) : num(v));
      bars += '<rect x="' + x + '" y="' + y + '" width="' + Math.max(6, bw - 8) + '" height="' + Math.max(1, bh) + '" rx="4" fill="' + color + '"></rect>';
      bars += '<text x="' + (x + (bw - 8) / 2) + '" y="' + (h - 6) + '" font-size="9.5" text-anchor="middle" fill="#667085" transform="rotate(-30 ' + (x + (bw - 8) / 2) + ',' + (h - 6) + ')">' + esc(label) + '</text>';
      bars += '<text x="' + (x + (bw - 8) / 2) + '" y="' + (v >= 0 ? y - 5 : y + bh + 12) + '" font-size="9.5" text-anchor="middle" fill="#344054">' + esc(valTxt) + '</text>';
    });
    if (!data.length) return '<div class="small">No data available for this slice.</div>';
    return '<svg viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="xMidYMid meet">' +
      '<line x1="' + pad + '" x2="' + (w - pad) + '" y1="' + mid + '" y2="' + mid + '" stroke="#c9d3e0" stroke-dasharray="4 3"/>' +
      bars + '</svg>';
  }

  function svgLines(series, opts) {
    opts = opts || {};
    var w = 720, h = 260, pad = 46;
    var allVals = [];
    series.forEach(function (s) { s.data.forEach(function (d) { allVals.push(d[1]); }); });
    if (!allVals.length) return '<div class="small">No time-series data available for this slice.</div>';
    var minV = Math.min.apply(null, allVals.concat([0]));
    var maxV = Math.max.apply(null, allVals.concat([1]));
    var range = (maxV - minV) || 1;
    function sy(v) { return h - pad - ((v - minV) / range) * (h - 2 * pad); }
    var maxLen = Math.max.apply(null, series.map(function (s) { return s.data.length; }).concat([1]));
    function sx(i) { return pad + i * (w - 2 * pad) / Math.max(maxLen - 1, 1); }
    var colors = ['#1f5eff', '#10b981', '#f79009', '#d92d20'];
    var svg = '<svg viewBox="0 0 ' + w + ' ' + h + '" preserveAspectRatio="xMidYMid meet">';
    svg += '<line x1="' + pad + '" x2="' + (w - pad) + '" y1="' + sy(0) + '" y2="' + sy(0) + '" stroke="#c9d3e0" stroke-dasharray="4 3"/>';
    series.forEach(function (s, si) {
      var pts = s.data.map(function (d, i) { return sx(i) + ',' + sy(d[1]); }).join(' ');
      svg += '<polyline points="' + pts + '" fill="none" stroke="' + colors[si % colors.length] + '" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>';
      s.data.forEach(function (d, i) {
        svg += '<circle cx="' + sx(i) + '" cy="' + sy(d[1]) + '" r="2.6" fill="' + colors[si % colors.length] + '"><title>' + esc(d[0]) + ': ' + esc(opts.money ? money(d[1]) : (opts.pct ? pct(d[1]) : num(d[1], 1))) + '</title></circle>';
      });
    });
    svg += '<text x="' + pad + '" y="16" font-size="11" fill="#475467">' + series.map(function (s) { return '● ' + esc(s.name); }).join('   ') + '</text>';
    svg += '</svg>';
    return svg;
  }

  function gauge(v, label) {
    var p = Math.min(1, Math.max(0, Number(v) || 0));
    var color = p > 0.9 ? '#d92d20' : (p > 0.7 ? '#f79009' : '#099250');
    return '<div class="gaugewrap"><div class="small">' + esc(label) + '</div>' +
      '<div class="gaugebar"><div class="gaugefill" style="width:' + (p * 100) + '%;background:' + color + '"></div></div>' +
      '<div class="gaugeval" style="color:' + color + '">' + (p * 100).toFixed(1) + '%</div></div>';
  }

  function sevBadge(v, amber, red) {
    if (v >= red) return '<span class="badge high">High</span>';
    if (v >= amber) return '<span class="badge med">Medium</span>';
    return '<span class="badge low">Low</span>';
  }

  // ---------- UI shell ----------
  function kpiRow(items) {
    return '<div class="kpirow">' + items.map(function (x) {
      return '<div class="kpi"><div class="kpi-label">' + esc(x[0]) + '</div><div class="kpi-val">' + x[1] + '</div>' +
        (x[2] ? '<div class="kpi-hint">' + esc(x[2]) + '</div>' : '') + '</div>';
    }).join('') + '</div>';
  }
  function card(title, subtitle, inner, wide) {
    return '<div class="card' + (wide ? ' wide' : '') + '"><div class="card-head"><h3>' + esc(title) + '</h3>' +
      (subtitle ? '<div class="small">' + esc(subtitle) + '</div>' : '') + '</div><div class="card-body">' + inner + '</div></div>';
  }
  function dataTable(rows, cols, colLabels) {
    var head = cols.map(function (c, i) { return '<th>' + esc(colLabels ? colLabels[i] : c) + '</th>'; }).join('');
    var body = rows.map(function (r) {
      return '<tr>' + cols.map(function (c) { return '<td>' + esc(fmtCell(c, r[c])) + '</td>'; }).join('') + '</tr>';
    }).join('');
    if (!rows.length) return '<div class="small">No records match this slice.</div>';
    return '<div class="tablewrap"><table><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>';
  }
  function fmtCell(c, v) {
    if (v === undefined || v === null || v === '') return '';
    if (c.indexOf('_usd') !== -1 || c === 'predicted_pnl_dv01' || c === 'actual_pnl') return money(v);
    if (c.indexOf('_pct') !== -1) return pct(v);
    return v;
  }

  function renderTabs() {
    var el = document.getElementById('tabbar');
    el.innerHTML = TABS.map(function (t) {
      return '<button type="button" class="tab' + (t.id === TAB ? ' on' : '') + '" data-tab="' + t.id + '">' + esc(t.label) + '</button>';
    }).join('');
    var btns = el.querySelectorAll('.tab');
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener('click', function (e) {
        TAB = e.currentTarget.getAttribute('data-tab');
        renderTabs();
        renderActive();
      });
    }
  }

  // ---------- filters ----------
  function populateFilterOptions() {
    var configs = [
      ['fSegment', 'business_segment'],
      ['fComponent', 'portfolio_component'],
      ['fProduct', 'product_type'],
      ['fAgency', 'agency_investor']
    ];
    configs.forEach(function (cfg) {
      var sel = document.getElementById(cfg[0]);
      uniq(cfg[1]).forEach(function (v) {
        var o = document.createElement('option');
        o.value = v; o.textContent = v;
        sel.appendChild(o);
      });
    });
  }

  function applyFilters() {
    var seg = document.getElementById('fSegment').value;
    var comp = document.getElementById('fComponent').value;
    var prod = document.getElementById('fProduct').value;
    var ag = document.getElementById('fAgency').value;
    var minGap = parseFloat(document.getElementById('fCprGap').value);
    var minUtil = parseFloat(document.getElementById('fDvUtil').value);
    var kw = (document.getElementById('fKeyword').value || '').toLowerCase().trim();

    F = D.filter(function (o) {
      if (seg !== 'All' && o.business_segment !== seg) return false;
      if (comp !== 'All' && o.portfolio_component !== comp) return false;
      if (prod !== 'All' && o.product_type !== prod) return false;
      if (ag !== 'All' && o.agency_investor !== ag) return false;
      if (isFinite(minGap) && Number(o.cpr_gap_pct) < minGap) return false;
      if (isFinite(minUtil) && Number(o.dv01_limit_utilization_pct) < minUtil) return false;
      if (kw) {
        var hay = (o.portfolio_component + ' ' + o.product_type + ' ' + o.agency_investor + ' ' +
          o.warehouse_line + ' ' + o.risk_narrative + ' ' + o.ebo_candidate_flag).toLowerCase();
        if (hay.indexOf(kw) === -1) return false;
      }
      return true;
    });
    document.getElementById('recordPill').textContent = num(F.length) + ' of ' + num(D.length) + ' records';
    renderActive();
  }

  function resetFilters() {
    ['fSegment', 'fComponent', 'fProduct', 'fAgency'].forEach(function (id) { document.getElementById(id).value = 'All'; });
    document.getElementById('fCprGap').value = '';
    document.getElementById('fDvUtil').value = '';
    document.getElementById('fKeyword').value = '';
    F = D.slice();
    document.getElementById('recordPill').textContent = num(D.length) + ' records loaded';
    renderActive();
  }

  function exportCSV() {
    if (!F.length) return;
    var cols = Object.keys(F[0]);
    var lines = [cols.join(',')];
    F.forEach(function (o) {
      lines.push(cols.map(function (c) {
        var v = o[c] === undefined || o[c] === null ? '' : String(o[c]);
        return '"' + v.replace(/"/g, '""') + '"';
      }).join(','));
    });
    var blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = 'pennymac_poc_filtered_export.csv';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // ---------- metrics ----------
  function computeMetrics(a) {
    return {
      rows: a.length,
      upb: sum(a, 'current_upb_usd'),
      portfolioDv01: sum(a, 'portfolio_dv01_usd'),
      hedgeDv01: sum(a, 'hedge_dv01'),
      netDv01: sum(a, 'net_dv01_after_hedge'),
      dvUtil: avg(a, 'dv01_limit_utilization_pct'),
      predictedPnl: sum(a, 'predicted_pnl_dv01'),
      actualPnl: sum(a, 'actual_pnl'),
      prepay01: sum(a, 'prepay01_usd'),
      prepayUtil: avg(a, 'prepay_utilization_pct'),
      cpr: avg(a, 'current_cpr_pct'),
      mcpr: avg(a, 'modeled_cpr_pct'),
      cprGap: avg(a, 'cpr_gap_pct'),
      psa: avg(a, 'current_psa'),
      msrValue: sum(a, 'msr_value_usd'),
      msrImpact: sum(a, 'msr_value_change_cpr_usd'),
      expRunoff: sum(a, 'expected_runoff_usd'),
      actRunoff: sum(a, 'actual_runoff_usd'),
      whUtil: avg(a, 'warehouse_utilization_pct'),
      marginCall: sum(a, 'margin_call_usd'),
      liqBuffer: sum(a, 'liquidity_buffer_usd'),
      eboCount: a.filter(function (o) { return o.ebo_candidate_flag === 'Y'; }).length,
      defectCount: a.filter(function (o) { return o.defect_risk_flag === 'Y'; }).length
    };
  }

  // ---------- deterministic local narrative (grounding layer / offline fallback) ----------
  function buildLocalNarrative(a, intent, m) {
    var topUpb = groupAgg(a, 'portfolio_component', 'current_upb_usd')[0] || ['N/A', 0];
    var topDv01 = groupAgg(a, 'portfolio_component', 'net_dv01_after_hedge')[0] || ['N/A', 0];
    var topPrepay = groupAgg(a, 'portfolio_component', 'prepay01_usd')[0] || ['N/A', 0];

    var scopeBits = [];
    if (intent.agency) scopeBits.push('agency/investor = ' + intent.agency);
    if (intent.product) scopeBits.push('product = ' + intent.product);
    if (intent.component) scopeBits.push('portfolio component = ' + intent.component);
    if (intent.thresholds.length) scopeBits.push(intent.thresholds.map(function (t) { return t.field + ' ' + t.op + ' ' + pct(t.value); }).join(', '));
    var scopeLine = scopeBits.length ? ' Scope applied from the question: ' + scopeBits.join('; ') + '.' : '';

    var focusLabel = { market: 'interest-rate / DV01 risk', prepay: 'prepayment speed / MSR risk', funding: 'funding & liquidity risk', servicing: 'production & servicing risk', overview: 'overall portfolio risk' }[intent.focus];

    var risks = [];
    if (Math.abs(m.prepay01) > Math.abs(m.netDv01)) risks.push('prepayment sensitivity (Prepay01) currently exceeds residual rate sensitivity (net DV01), so speed/model risk is the more material driver for this slice');
    if (m.cprGap > 0.02) risks.push('current CPR is running more than 2 points ahead of the modeled CPR assumption, which will pressure MSR valuation and pull forward runoff');
    if (m.whUtil > 0.85) risks.push('average warehouse utilization is above the 85% internal review threshold');
    if (m.dvUtil > 0.7) risks.push('DV01 limit utilization is elevated, warranting a hedge-effectiveness review');
    if (m.prepayUtil > 0.7) risks.push('Prepay01 limit utilization is elevated relative to the configured sample threshold');
    if (m.eboCount > 0) risks.push(m.eboCount + ' record(s) are flagged as early-buyout (EBO) candidates');
    if (m.defectCount > 0) risks.push(m.defectCount + ' production record(s) carry a defect-risk flag with potential repurchase exposure');

    var summary = (intent.hasQuestion ? 'In response to "' + esc(intent.raw) + '", focusing on ' + focusLabel + ':' : 'General portfolio risk review (' + focusLabel + '):') +
      scopeLine + ' The scoped population contains ' + num(m.rows) + ' records representing ' + money(m.upb) + ' of current UPB. ' +
      'Net DV01 after hedge is ' + money(m.netDv01) + ' (portfolio DV01 of ' + money(m.portfolioDv01) + ' offset by ' + money(m.hedgeDv01) + ' of hedge DV01). ' +
      'Total Prepay01 (P&L sensitivity to a 1-point change in prepayment speed) is ' + money(m.prepay01) + '. ' +
      'Average current CPR is ' + pct(m.cpr) + ' against a modeled CPR of ' + pct(m.mcpr) + ', an average gap of ' + pct(m.cprGap) + '.';

    var drivers = 'The largest UPB contributor in this slice is <b>' + esc(topUpb[0]) + '</b> (' + money(topUpb[1]) + '). The largest residual DV01 contributor is <b>' +
      esc(topDv01[0]) + '</b> (' + money(topDv01[1]) + '). The largest Prepay01 contributor is <b>' + esc(topPrepay[0]) + '</b> (' + money(topPrepay[1]) + ').';

    var conclusion = risks.length ? 'Key risk observations: ' + risks.join('; ') + '.' : 'No individual threshold breach stands out in this slice; risk levels appear within normal monitoring ranges.';

    return { summary: summary, drivers: drivers, conclusion: conclusion };
  }

  function buildActions(intent, m) {
    var actions = [];
    if (intent.focus === 'market' || intent.focus === 'overview') actions.push('Reconcile net DV01 after hedge against the DV01 limit to confirm hedge effectiveness is holding.');
    if (intent.focus === 'prepay' || intent.focus === 'overview') actions.push('Rank records/components by |Prepay01| and CPR gap to prioritize MSR valuation review.');
    if (intent.focus === 'funding' || intent.focus === 'overview') actions.push('Escalate any warehouse line above 85% utilization together with the associated margin-call trend.');
    if (intent.focus === 'servicing' || intent.focus === 'overview') actions.push('Route EBO-flagged and defect/repurchase-flagged records to the relevant servicing/QC workflow.');
    if (!actions.length) actions.push('Review the driver table and exceptions below with the relevant desk before finalizing a management view.');
    return actions;
  }

  // ---------- Live Copilot (LLM) call with graceful fallback ----------
  function callLiveCopilot(payload) {
    if (typeof fetch !== 'function') return Promise.reject(new Error('fetch not available'));
    var controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    var timer = controller ? setTimeout(function () { controller.abort(); }, COPILOT_TIMEOUT_MS) : null;
    return fetch(COPILOT_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller ? controller.signal : undefined
    }).then(function (res) {
      if (timer) clearTimeout(timer);
      if (!res.ok) throw new Error('Copilot backend responded with status ' + res.status);
      return res.json();
    }).catch(function (err) {
      if (timer) clearTimeout(timer);
      throw err;
    });
  }

  function setBadge(html) {
    var el = document.getElementById('liveBadge');
    if (el) el.innerHTML = html;
  }

  // ---------- Risk Copilot Report (question-aware) ----------
  function renderCopilotReport() {
    var myToken = ++renderToken;
    var question = document.getElementById('askInput') ? document.getElementById('askInput').value : '';
    var intent = parseIntent(question);
    var scope = applyIntentScope(F, intent);
    var a = scope.data;
    var m = computeMetrics(a);
    var local = buildLocalNarrative(a, intent, m);
    var actions = buildActions(intent, m);

    var driverRows = groupAgg(a, 'portfolio_component', 'current_upb_usd').slice(0, 7).map(function (x) {
      var sub = a.filter(function (o) { return (o.portfolio_component || 'Unassigned') === x[0]; });
      return {
        component: x[0],
        current_upb_usd: x[1],
        net_dv01_after_hedge: sum(sub, 'net_dv01_after_hedge'),
        prepay01_usd: sum(sub, 'prepay01_usd'),
        current_cpr_pct: avg(sub, 'current_cpr_pct'),
        cpr_gap_pct: avg(sub, 'cpr_gap_pct'),
        warehouse_utilization_pct: avg(sub, 'warehouse_utilization_pct')
      };
    });

    var sortField = intent.sortField;
    var topN = intent.topN || 12;
    var exceptions = a.slice().sort(function (x, y) {
      return Math.abs(Number(y[sortField]) || 0) - Math.abs(Number(x[sortField]) || 0);
    }).slice(0, topN);

    var scorecardRows = [
      ['Rate Risk', 'DV01 limit utilization', pct(m.dvUtil), sevBadge(m.dvUtil, 0.7, 0.9), 'Residual rate exposure after hedge, relative to configured limit.'],
      ['Prepayment Risk', 'Prepay01 limit utilization', pct(m.prepayUtil), sevBadge(m.prepayUtil, 0.7, 0.9), 'Speed sensitivity relative to configured limit.'],
      ['Model Risk', 'CPR gap (abs)', pct(Math.abs(m.cprGap)), sevBadge(Math.abs(m.cprGap), 0.015, 0.03), 'Current CPR vs. modeled CPR assumption.'],
      ['Funding Risk', 'Warehouse utilization', pct(m.whUtil), sevBadge(m.whUtil, 0.7, 0.85), 'Average utilization across assigned funding lines.']
    ];

    // Focus-driven chart selection: DIFFERENT questions now genuinely show DIFFERENT charts.
    var krd = [['2Y', sum(a, 'krd_2y_usd')], ['5Y', sum(a, 'krd_5y_usd')], ['10Y', sum(a, 'krd_10y_usd')], ['30Y', sum(a, 'krd_30y_usd')]];
    var chartsHtml;
    if (intent.focus === 'market') {
      chartsHtml =
        card('DV01 by Component', 'Portfolio DV01 exposure (this slice)', svgBars(groupAgg(a, 'portfolio_component', 'portfolio_dv01_usd').slice(0, 8), { money: true })) +
        card('Key Rate Duration (KRD)', '2Y / 5Y / 10Y / 30Y curve exposure', svgBars(krd, { money: true })) +
        card('Predicted vs. Actual P&L', 'Monthly DV01 explain (this slice)', svgLines([
          { name: 'Predicted', data: monthlyAgg(a, 'predicted_pnl_dv01') },
          { name: 'Actual', data: monthlyAgg(a, 'actual_pnl') }
        ], { money: true }), true);
    } else if (intent.focus === 'prepay') {
      chartsHtml =
        card('Actual vs. Modeled CPR', 'Average monthly speed (this slice)', svgLines([
          { name: 'Current CPR', data: monthlyAgg(a, 'current_cpr_pct', 'avg') },
          { name: 'Modeled CPR', data: monthlyAgg(a, 'modeled_cpr_pct', 'avg') }
        ], { pct: true })) +
        card('Prepay01 by Component', 'Speed sensitivity (this slice)', svgBars(groupAgg(a, 'portfolio_component', 'prepay01_usd').slice(0, 8), { money: true })) +
        card('Actual vs. Expected Runoff', 'Monthly runoff comparison (this slice)', svgLines([
          { name: 'Actual', data: monthlyAgg(a, 'actual_runoff_usd') },
          { name: 'Expected', data: monthlyAgg(a, 'expected_runoff_usd') }
        ], { money: true }), true);
    } else if (intent.focus === 'funding') {
      chartsHtml =
        card('Warehouse Utilization', 'Average by warehouse line (this slice)', svgBars(groupAgg(a, 'warehouse_line', 'warehouse_utilization_pct', 'avg').slice(0, 8), { pct: true })) +
        card('Margin Call by Warehouse', 'Total margin call exposure (this slice)', svgBars(groupAgg(a, 'warehouse_line', 'margin_call_usd').slice(0, 8), { money: true })) +
        card('Liquidity Buffer by Warehouse', 'Available liquidity (this slice)', svgBars(groupAgg(a, 'warehouse_line', 'liquidity_buffer_usd').slice(0, 8), { money: true }), true);
    } else if (intent.focus === 'servicing') {
      var delinq = {};
      a.forEach(function (o) { var k = o.delinquency_bucket || 'NA'; delinq[k] = (delinq[k] || 0) + 1; });
      chartsHtml =
        card('Delinquency Buckets', 'Record count by status (this slice)', svgBars(Object.keys(delinq).map(function (k) { return [k, delinq[k]]; }))) +
        card('Production / Servicing Mix', 'Current UPB by segment (this slice)', svgBars(groupAgg(a, 'business_segment', 'current_upb_usd'), { money: true })) +
        card('Agency / Investor Mix', 'Current UPB by investor (this slice)', svgBars(groupAgg(a, 'agency_investor', 'current_upb_usd').slice(0, 8), { money: true }), true);
    } else {
      chartsHtml =
        card('Net DV01 by Component', 'Residual rate exposure (this slice)', svgBars(groupAgg(a, 'portfolio_component', 'net_dv01_after_hedge').slice(0, 8), { money: true })) +
        card('Prepay01 by Component', 'P&L sensitivity per 1-point speed shift (this slice)', svgBars(groupAgg(a, 'portfolio_component', 'prepay01_usd').slice(0, 8), { money: true })) +
        card('Actual vs. Expected Runoff (Monthly)', 'Speed-driven UPB runoff trend (this slice)', svgLines([
          { name: 'Actual runoff', data: monthlyAgg(a, 'actual_runoff_usd') },
          { name: 'Expected runoff', data: monthlyAgg(a, 'expected_runoff_usd') }
        ], { money: true }), true);
    }

    var scopeNote = '';
    if (scope.emptyFallback) scopeNote = '<div class="callout warn">No records matched the specific criteria in this question, so the report below falls back to the full currently-filtered population.</div>';
    else if (scope.narrowed) scopeNote = '<div class="callout info">This report is scoped to ' + num(a.length) + ' record(s) matching the question, out of ' + num(F.length) + ' in the current filter selection.</div>';

    var html = '';
    html += '<div class="reportbar"><div class="chips">' +
      '<span class="chip">' + num(m.rows) + ' records</span>' +
      '<span class="chip">' + money(m.upb) + ' UPB</span>' +
      '<span class="chip">' + money(m.netDv01) + ' Net DV01</span>' +
      '<span class="chip">' + money(m.prepay01) + ' Prepay01</span>' +
      '<span class="chip focus">Focus: ' + esc(intent.focus) + '</span>' +
      '</div><button type="button" class="btn ghost" id="printBtn">🖨️ Print / Save as PDF</button></div>';

    html += scopeNote;

    html += '<div class="report">';
    html += '<h2>Risk Copilot Report <span id="liveBadge" class="livebadge checking">● checking live agent…</span></h2>';
    html += '<div class="reportmeta">Generated ' + esc(META.generated || '') + ' &middot; Question: <em>' + esc(question || 'General portfolio risk review') + '</em></div>';

    html += '<div class="section"><h3>1. Executive Summary</h3><p id="narrSummary">' + local.summary + '</p><p id="narrDrivers">' + local.drivers + '</p><p id="narrConclusion">' + local.conclusion + '</p></div>';

    html += '<div class="section"><h3>2. Risk Scorecard</h3>' +
      '<div class="tablewrap"><table><thead><tr><th>Risk Area</th><th>Metric</th><th>Value</th><th>Assessment</th><th>Interpretation</th></tr></thead><tbody>' +
      scorecardRows.map(function (r) { return '<tr><td>' + esc(r[0]) + '</td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td><td>' + r[3] + '</td><td>' + esc(r[4]) + '</td></tr>'; }).join('') +
      '</tbody></table></div></div>';

    html += '<div class="section"><h3>3. Recommended Actions</h3><ul id="narrActions">' + actions.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + '</ul></div>';

    html += '<div class="section"><h3>4. Portfolio Component Driver Table</h3>' +
      dataTable(driverRows, ['component', 'current_upb_usd', 'net_dv01_after_hedge', 'prepay01_usd', 'current_cpr_pct', 'cpr_gap_pct', 'warehouse_utilization_pct'],
        ['Portfolio Component', 'Current UPB', 'Net DV01', 'Prepay01', 'Avg CPR', 'CPR Gap', 'Whse Util.']) + '</div>';

    html += '<div class="chartsgrid">' + chartsHtml + '</div>';

    html += '<div class="section"><h3>5. Key Records for Analyst Review</h3>' +
      '<div class="small" style="margin-bottom:8px">Sorted by ' + esc(sortField) + (intent.topN ? (', showing top ' + intent.topN) : '') + '.</div>' +
      dataTable(exceptions, ['record_id', 'portfolio_component', 'agency_investor', 'current_upb_usd', 'current_cpr_pct', 'cpr_gap_pct', 'prepay01_usd', 'net_dv01_after_hedge', 'warehouse_utilization_pct'],
        ['Record', 'Component', 'Agency', 'UPB', 'CPR', 'CPR Gap', 'Prepay01', 'Net DV01', 'Whse Util.']) + '</div>';

    html += '<div class="reportfooter">' + esc(META.disclaimer || '') + '</div>';
    html += '</div>'; // .report

    document.getElementById('mainArea').innerHTML = html;

    var printBtn = document.getElementById('printBtn');
    if (printBtn) printBtn.addEventListener('click', function () { window.print(); });

    // ---- Attempt the LIVE agent call. Charts/tables/scorecard stay deterministic
    //      (computed above from real data); only the narrative prose may be
    //      replaced by the live model, and only if the backend responds. ----
    var payload = {
      question: question,
      intent: intent,
      metrics: m,
      drivers: driverRows,
      sample_records: exceptions.slice(0, 6)
    };
    callLiveCopilot(payload).then(function (resp) {
      if (myToken !== renderToken) return; // user moved on to a different report; ignore stale response
      if (resp && resp.narrative_html) {
        var summaryEl = document.getElementById('narrSummary');
        if (summaryEl) summaryEl.innerHTML = resp.narrative_html;
        var driversEl = document.getElementById('narrDrivers');
        if (driversEl && resp.drivers_html) driversEl.innerHTML = resp.drivers_html; else if (driversEl) driversEl.style.display = 'none';
        var conclEl = document.getElementById('narrConclusion');
        if (conclEl && resp.conclusion_html) conclEl.innerHTML = resp.conclusion_html;
        setBadge('<span class="dot on"></span> Live agent connected (' + esc(resp.source || 'model') + (resp.model ? ' · ' + esc(resp.model) : '') + ')');
      } else {
        setBadge('<span class="dot off"></span> Live agent offline — showing built-in analyst engine');
      }
    }).catch(function () {
      if (myToken !== renderToken) return;
      setBadge('<span class="dot off"></span> Live agent offline — showing built-in analyst engine');
    });
  }

  // ---------- Executive dashboard ----------
  function renderExecutive() {
    var a = F, m = computeMetrics(a);
    var html = kpiRow([
      ['Records', num(m.rows), 'Current filtered population'],
      ['Current UPB', money(m.upb), 'Portfolio exposure'],
      ['Net DV01', money(m.netDv01), 'After hedge offset'],
      ['Total Prepay01', money(m.prepay01), 'P&L per speed point'],
      ['Avg Current CPR', pct(m.cpr), 'Current speed'],
      ['DV01 Limit Util.', pct(m.dvUtil), 'Risk appetite usage']
    ]);
    html += '<div class="chartsgrid" style="margin-top:16px">' +
      card('Portfolio Exposure by Component', 'Current UPB', svgBars(groupAgg(a, 'portfolio_component', 'current_upb_usd').slice(0, 10), { money: true })) +
      card('Net DV01 After Hedge', 'By portfolio component', svgBars(groupAgg(a, 'portfolio_component', 'net_dv01_after_hedge').slice(0, 10), { money: true })) +
      card('Prepay01 Waterfall', 'P&L per 1-point speed shift', svgBars(groupAgg(a, 'portfolio_component', 'prepay01_usd').slice(0, 10), { money: true })) +
      card('DV01 Limit Utilization', 'Average of filtered population', gauge(m.dvUtil, 'Average DV01 limit consumed')) +
      '</div>';
    document.getElementById('mainArea').innerHTML = html;
  }

  // ---------- Market Risk ----------
  function renderMarket() {
    var a = F, m = computeMetrics(a);
    var krd = [
      ['2Y', sum(a, 'krd_2y_usd')], ['5Y', sum(a, 'krd_5y_usd')],
      ['10Y', sum(a, 'krd_10y_usd')], ['30Y', sum(a, 'krd_30y_usd')]
    ];
    var html = kpiRow([
      ['Portfolio DV01', money(m.portfolioDv01), 'Before hedge'],
      ['Hedge DV01', money(m.hedgeDv01), 'Offset'],
      ['Net DV01', money(m.netDv01), 'After hedge'],
      ['Predicted P&L', money(m.predictedPnl), 'DV01 × rate move'],
      ['Actual P&L', money(m.actualPnl), 'Illustrative'],
      ['DV01 Limit Util.', pct(m.dvUtil), 'Risk appetite']
    ]);
    html += '<div class="chartsgrid" style="margin-top:16px">' +
      card('DV01 Waterfall by Component', 'Portfolio DV01 exposure', svgBars(groupAgg(a, 'portfolio_component', 'portfolio_dv01_usd').slice(0, 10), { money: true })) +
      card('Key Rate Duration (KRD)', '2Y / 5Y / 10Y / 30Y curve exposure', svgBars(krd, { money: true })) +
      card('Predicted vs. Actual P&L', 'Monthly DV01 explain validation', svgLines([
        { name: 'Predicted', data: monthlyAgg(a, 'predicted_pnl_dv01') },
        { name: 'Actual', data: monthlyAgg(a, 'actual_pnl') }
      ], { money: true }), true) +
      '</div>';
    document.getElementById('mainArea').innerHTML = html;
  }

  // ---------- Prepayment & MSR ----------
  function renderPrepay() {
    var a = F, m = computeMetrics(a);
    var buckets = { '<100': 0, '100-200': 0, '200-400': 0, '400+': 0 };
    a.forEach(function (o) {
      var x = Number(o.current_psa) || 0;
      if (x < 100) buckets['<100']++;
      else if (x < 200) buckets['100-200']++;
      else if (x < 400) buckets['200-400']++;
      else buckets['400+']++;
    });
    var psaData = Object.keys(buckets).map(function (k) { return [k, buckets[k]]; });

    var html = kpiRow([
      ['Avg Current CPR', pct(m.cpr), 'Observed speed'],
      ['Avg Modeled CPR', pct(m.mcpr), 'Model expectation'],
      ['Avg CPR Gap', pct(m.cprGap), 'Actual minus model'],
      ['Avg Current PSA', num(m.psa, 1), 'PSA speed equivalent'],
      ['Total Prepay01', money(m.prepay01), 'Speed sensitivity'],
      ['MSR CPR Impact', money(m.msrImpact), 'Value bridge']
    ]);
    html += '<div class="chartsgrid" style="margin-top:16px">' +
      card('Actual vs. Modeled CPR', 'Average monthly speed', svgLines([
        { name: 'Current CPR', data: monthlyAgg(a, 'current_cpr_pct', 'avg') },
        { name: 'Modeled CPR', data: monthlyAgg(a, 'modeled_cpr_pct', 'avg') }
      ], { pct: true })) +
      card('PSA Speed Distribution', 'Record count by PSA bucket', svgBars(psaData)) +
      card('Prepay01 by Component', 'Speed-sensitivity by component', svgBars(groupAgg(a, 'portfolio_component', 'prepay01_usd').slice(0, 8), { money: true })) +
      card('MSR Value Change from CPR Gap', 'Value bridge by component', svgBars(groupAgg(a, 'portfolio_component', 'msr_value_change_cpr_usd').slice(0, 8), { money: true })) +
      card('Actual vs. Expected Runoff', 'Monthly runoff comparison', svgLines([
        { name: 'Actual', data: monthlyAgg(a, 'actual_runoff_usd') },
        { name: 'Expected', data: monthlyAgg(a, 'expected_runoff_usd') }
      ], { money: true }), true) +
      '</div>';
    document.getElementById('mainArea').innerHTML = html;
  }

  // ---------- Funding & Liquidity ----------
  function renderFunding() {
    var a = F, m = computeMetrics(a);
    var html = kpiRow([
      ['Margin Calls', money(m.marginCall), 'Total'],
      ['Liquidity Buffer', money(m.liqBuffer), 'Available'],
      ['Avg Warehouse Util.', pct(m.whUtil), 'Utilization'],
      ['High Util. Records', num(a.filter(function (o) { return Number(o.warehouse_utilization_pct) > 0.85; }).length), 'Warehouse > 85%'],
      ['EBO Candidates', num(m.eboCount), 'Default / EBO workflow'],
      ['Defect Flags', num(m.defectCount), 'QC review candidates']
    ]);
    html += '<div class="chartsgrid" style="margin-top:16px">' +
      card('Warehouse Utilization', 'Average by warehouse line', svgBars(groupAgg(a, 'warehouse_line', 'warehouse_utilization_pct', 'avg').slice(0, 10), { pct: true })) +
      card('Margin Call by Warehouse', 'Total margin call exposure', svgBars(groupAgg(a, 'warehouse_line', 'margin_call_usd').slice(0, 10), { money: true })) +
      card('Liquidity Buffer by Warehouse', 'Available liquidity by line', svgBars(groupAgg(a, 'warehouse_line', 'liquidity_buffer_usd').slice(0, 10), { money: true })) +
      card('Repo Haircut by Warehouse', 'Average haircut by line', svgBars(groupAgg(a, 'warehouse_line', 'repo_haircut_pct', 'avg').slice(0, 10), { pct: true })) +
      '</div>';
    document.getElementById('mainArea').innerHTML = html;
  }

  // ---------- Production & Servicing ----------
  function renderServicing() {
    var a = F;
    var html = kpiRow([
      ['Production Rows', num(a.filter(function (o) { return o.business_segment === 'Production'; }).length), 'Generated records'],
      ['Servicing Rows', num(a.filter(function (o) { return o.business_segment === 'Servicing'; }).length), 'Generated records'],
      ['MSR Value', money(sum(a, 'msr_value_usd')), 'Illustrative'],
      ['Servicing UPB', money(sum(a, 'servicing_upb_usd')), 'Servicing exposure'],
      ['Repurchase Flags', num(a.filter(function (o) { return o.repurchase_risk_flag === 'Y'; }).length), 'QC/repurchase review'],
      ['PMT-Related', num(a.filter(function (o) { return o.pmt_related_flag === 'Y'; }).length), 'Related-party records']
    ]);
    var delinq = {};
    a.forEach(function (o) { var k = o.delinquency_bucket || 'NA'; delinq[k] = (delinq[k] || 0) + 1; });
    var delinqData = Object.keys(delinq).map(function (k) { return [k, delinq[k]]; });

    html += '<div class="chartsgrid" style="margin-top:16px">' +
      card('Production / Servicing Mix', 'Current UPB by segment', svgBars(groupAgg(a, 'business_segment', 'current_upb_usd'), { money: true })) +
      card('Product Type Mix', 'Current UPB by product', svgBars(groupAgg(a, 'product_type', 'current_upb_usd'), { money: true })) +
      card('Agency / Investor Mix', 'Current UPB by investor', svgBars(groupAgg(a, 'agency_investor', 'current_upb_usd'), { money: true })) +
      card('Delinquency Buckets', 'Record count by status', svgBars(delinqData)) +
      '</div>';

    var top = a.slice().sort(function (x, y) { return (Number(y.current_upb_usd) || 0) - (Number(x.current_upb_usd) || 0); }).slice(0, 15);
    html += '<div style="margin-top:16px">' + card('Top Exposure Records', 'Sorted by current UPB', dataTable(top,
      ['record_id', 'portfolio_component', 'product_type', 'agency_investor', 'current_upb_usd', 'current_cpr_pct', 'net_dv01_after_hedge', 'prepay01_usd'],
      ['Record', 'Component', 'Product', 'Agency', 'UPB', 'CPR', 'Net DV01', 'Prepay01']), true) + '</div>';

    document.getElementById('mainArea').innerHTML = html;
  }

  // ---------- Data Dictionary ----------
  function renderDictionary() {
    var rows = DICT.map(function (d) { return { field: d.field, type: d.type, definition: d.definition }; });
    var html = card('Data Dictionary', DICT.length + ' attributes documented', dataTable(rows, ['field', 'type', 'definition'], ['Field', 'Type', 'Definition']), true);
    document.getElementById('mainArea').innerHTML = html;
  }

  // ---------- router ----------
  function renderActive() {
    if (TAB === 'copilot') renderCopilotReport();
    else if (TAB === 'exec') renderExecutive();
    else if (TAB === 'market') renderMarket();
    else if (TAB === 'prepay') renderPrepay();
    else if (TAB === 'funding') renderFunding();
    else if (TAB === 'servicing') renderServicing();
    else if (TAB === 'dictionary') renderDictionary();
  }

  function setQuestionAndGenerate(q) {
    var el = document.getElementById('askInput');
    if (el) el.value = q;
    TAB = 'copilot';
    renderTabs();
    renderActive();
  }

  function init() {
    document.getElementById('metaLine').textContent =
      num(META.rows || D.length) + ' rows  |  ' + (META.cols || Object.keys(D[0] || {}).length) + ' attributes  |  Generated ' + (META.generated || '');
    document.getElementById('recordPill').textContent = num(D.length) + ' records loaded';
    document.getElementById('disclaimer').textContent = META.disclaimer || '';

    populateFilterOptions();
    renderTabs();

    document.getElementById('applyBtn').addEventListener('click', applyFilters);
    document.getElementById('resetBtn').addEventListener('click', resetFilters);
    document.getElementById('csvBtn').addEventListener('click', exportCSV);

    document.getElementById('generateBtn').addEventListener('click', function () {
      TAB = 'copilot'; renderTabs(); renderActive();
    });
    document.getElementById('quickPrepay').addEventListener('click', function () {
      setQuestionAndGenerate('Generate a report on Prepay01, CPR gap and MSR value impact');
    });
    document.getElementById('quickDv01').addEventListener('click', function () {
      setQuestionAndGenerate('Generate a report on DV01, KRD and hedge offset effectiveness');
    });
    document.getElementById('quickFunding').addEventListener('click', function () {
      setQuestionAndGenerate('Identify funding, warehouse and liquidity pressure points');
    });
    document.getElementById('quickExec').addEventListener('click', function () {
      setQuestionAndGenerate('Provide an executive summary of overall portfolio risk');
    });

    var askInput = document.getElementById('askInput');
    askInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        TAB = 'copilot'; renderTabs(); renderActive();
      }
    });

    renderActive();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose pure functions for testing / power-user console access.
  window.PennyMacRiskCopilot = {
    parseIntent: parseIntent,
    applyIntentScope: applyIntentScope,
    computeMetrics: computeMetrics,
    buildLocalNarrative: buildLocalNarrative
  };
})();
