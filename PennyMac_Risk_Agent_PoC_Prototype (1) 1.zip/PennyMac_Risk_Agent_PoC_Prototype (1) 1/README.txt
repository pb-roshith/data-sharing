PennyMac Capital Markets Risk Agent — PoC Prototype (v2: Live Copilot Agent)
=============================================================================

WHAT CHANGED IN v2
------------------
v1 of this prototype computed the same aggregate metrics regardless of the
question typed into the Risk Copilot box — only the question text itself was
echoed back into a template sentence. v2 fixes this at the root and adds a
real, optional live-agent integration:

1. QUESTION-AWARE SCOPING (works with zero external services)
   Every question is now parsed for entities (agency/investor, product,
   portfolio component), a risk "focus area" (market / prepay / funding /
   servicing / overview), threshold phrases ("CPR gap above 2%", "warehouse
   utilization over 85%"), and top-N requests ("top 10"). That parsed intent
   is used to further narrow the dataset BEFORE anything is computed, and to
   choose WHICH charts to show. Two different questions now genuinely
   produce different record counts, different numbers, different driver
   tables, and different charts — not just different sentences.

2. A REAL, OPTIONAL LIVE LLM AGENT (server.py)
   A small local backend can generate the narrative prose using an actual
   language model (Mistral AI), while the charts/tables/scorecard
   remain 100% deterministic (computed in the browser from the real dataset)
   so the model is only ever asked to explain numbers that are already
   trusted — never to invent them. If the backend isn't running, or a real
   model isn't configured, the app transparently falls back to its own
   built-in, question-aware narrative engine. Nothing ever breaks or hangs.


HOW TO RUN — TWO MODES
-----------------------

MODE A: Static / offline (no setup, exactly like v1)
    Double-click index.html.
    The Risk Copilot report is now question-aware even in this mode (see #1
    above) — this alone resolves the "same content regardless of question"
    issue. The badge at the top of the report will say
    "Live agent offline — showing built-in analyst engine". That is expected
    and fine for a self-contained demo with no backend.

MODE B: Live agent mode (real LLM-generated narrative)
    1. Install dependencies once:
           pip install -r requirements.txt
    2. Create a `.env` file in this directory with:

           MISTRAL_API_KEY=<your-key>
           MISTRAL_MODEL=mistral-small-latest
           MISTRAL_BASE_URL=https://api.mistral.ai/v1

       The backend loads this file automatically. `.env` is ignored by Git
       and must never be committed because it contains a secret.

    3. Start the backend:
           python server.py
    4. Open the browser to:
           http://127.0.0.1:8787/
       (Do NOT double-click index.html in this mode — the page must be
       served by server.py so the browser's same-origin fetch to
       /api/copilot works without any CORS configuration.)
    5. Ask a question and click "Generate Report". The badge in the report
       header will say "Live agent connected (mistral · <model>)" once a
       real response comes back.

    If you haven't set any credentials yet but still want to see the full
    round trip working, just run `python server.py` with no environment
    variables set — it runs in a clearly-labeled MOCK mode
    ("[MOCK LLM — configure MISTRAL_API_KEY for a real model]") so you can
    confirm the wiring before adding a real key.


WHAT'S INSIDE
-------------
- index.html      -> application shell (loads styles.css, data.js, app.js)
- styles.css       -> visual styling
- data.js          -> embedded synthetic dataset (20,000 rows x 51 attributes)
                      + full data dictionary. Generated for PoC purposes only —
                      NOT PennyMac production or customer data.
- app.js           -> all front-end logic: filtering, question-intent parsing,
                      scoping, SVG charts, local narrative engine, and the
                      live-agent fetch call with graceful fallback.
- server.py        -> optional local backend for live LLM-generated narrative.
- requirements.txt -> Python dependencies for server.py.
- tests/           -> automated test scripts used to validate this build
                      (see "HOW THIS WAS TESTED" below). Not required to run
                      the prototype — included for transparency.


TABS / MODULES
---------------
- Risk Copilot Report    -> ask a question, click "Generate Report" for a
                            question-scoped narrative + risk scorecard +
                            driver tables + charts that ACTUALLY CHANGE based
                            on what you ask.
- Executive Dashboard     -> top-level KPIs and portfolio exposure charts
                            (reflects the sidebar filters, not the question).
- Market Risk             -> DV01 / PV01 / Key Rate Duration / predicted vs
                            actual P&L.
- Prepayment & MSR        -> CPR / PSA / Prepay01 / MSR value bridge / runoff.
- Funding & Liquidity     -> warehouse utilization, margin calls, liquidity
                            buffer.
- Production & Servicing -> segment/product/agency mix, delinquency, top
                            exposures.
- Data Dictionary         -> full definitions for all 51 attributes.


TRY THESE QUESTIONS TO SEE THE DIFFERENCE
------------------------------------------
- "Generate an executive summary of overall portfolio risk"
- "Summarize DV01 and hedge effectiveness for GNMA"
- "Generate a report on Prepay01, CPR gap and MSR value impact"
- "Identify funding, warehouse and liquidity pressure points"
- "Show delinquency and production risk for the servicing book"
- "Which portfolio has the highest Prepay01 exposure? show top 5"
- "cpr gap above 3% for correspondent production"

Each of these produces a different record count, different focus-specific
charts, and a different narrative — both in static mode (built-in engine)
and in live mode (real LLM, grounded in the same computed numbers).


HOW THIS WAS TESTED
--------------------
Because this environment has no visual browser, correctness was verified
programmatically using Node's native fetch/DOM-adjacent tooling and Python's
FastAPI TestClient:
- tests/test_harness.js              -> exercises every tab, filter, and
                                        button via a lightweight DOM stub.
- tests/test_server.py               -> unit-tests the /api/copilot backend
                                        logic (mock mode, forced modes,
                                        graceful fallback on a bad/invalid
                                        Mistral endpoint) with no real network
                                        calls or API keys required.
- tests/test_live_integration_realdom.js
                                      -> launches the REAL server.py process
                                        and drives app.js against it using a
                                        genuine HTML/DOM parser (@xmldom),
                                        confirming the live badge, and that
                                        two different questions produce two
                                        different live-server narratives.
- tests/test_offline_fallback.js     -> confirms that with no backend
                                        reachable, five different questions
                                        still produce five distinct focus
                                        areas, five distinct scoped record
                                        counts, and five distinct narratives
                                        via the local fallback engine.

All four suites pass with clean exit codes.


KNOWN CHARACTERISTIC (NOT A BUG)
---------------------------------
Building a full report over the 20,000-row dataset takes roughly 0.3-0.8
seconds of computation (multiple chart aggregations, a driver table, and a
sorted exceptions table are all recomputed from scratch on every question).
This is expected given the data volume and is not a hang — if you want a
snappier feel for a live customer demo, this can be optimized further (e.g.
memoizing repeated aggregations) as a follow-up enhancement.


IMPORTANT
---------
This dataset is entirely SYNTHETIC / GENERATED for demonstration purposes.
It is NOT PennyMac production or customer data and should not be treated as
such. The live-agent integration sends only pre-computed, aggregate metrics
(not raw record-level data) to whichever model endpoint you configure.
