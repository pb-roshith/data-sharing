"""
PennyMac Capital Markets Risk Agent PoC — Live Copilot backend.

Run with:
    python server.py
Then open:
    http://127.0.0.1:8787/

This process does two things:
1. Serves the static PoC front end (index.html, app.js, styles.css, data.js)
   from the same origin, so the browser's fetch('/api/copilot', ...) call
   works with zero CORS configuration.
2. Exposes POST /api/copilot, which turns the already-computed, GROUNDED
   metrics that the front end sends (real numbers computed in the browser
   from the loaded dataset) into a natural-language narrative written by
   an LLM. The model is only ever asked to explain numbers we already
   trust — never to invent them. If the model call fails, is not
   configured, or times out, this endpoint returns None-ish sentinel
   fields and the front end silently keeps its own built-in narrative.

LIVE MODEL CONFIGURATION
------------------------
Mistral AI:
    set MISTRAL_API_KEY=<your-key>
    set MISTRAL_MODEL=mistral-small-latest             (optional, has a default)
    set MISTRAL_BASE_URL=https://api.mistral.ai/v1      (optional)

If none of the above are set, the server runs in MOCK mode: it still
returns a genuinely input-dependent narrative (built from the same
metrics/intent payload) so you can demo and test the full round-trip
before wiring a real key. Mock responses are clearly labeled as such.

You can force mock mode even with real credentials present by setting:
    set COPILOT_FORCE_MODE=mock
"""

import os
import json
import time
from typing import Optional, List, Dict, Any

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv

APP_DIR = os.path.dirname(os.path.abspath(__file__))
if os.environ.get("COPILOT_SKIP_DOTENV") != "1":
    load_dotenv(os.path.join(APP_DIR, ".env"))

app = FastAPI(title="PennyMac Risk Copilot PoC Backend")


# ---------------------------------------------------------------------------
# Request / response schema
# ---------------------------------------------------------------------------
class CopilotRequest(BaseModel):
    question: str = ""
    intent: Dict[str, Any] = {}
    metrics: Dict[str, Any] = {}
    drivers: List[Dict[str, Any]] = []
    sample_records: List[Dict[str, Any]] = []


class CopilotResponse(BaseModel):
    narrative_html: Optional[str] = None
    drivers_html: Optional[str] = None
    conclusion_html: Optional[str] = None
    source: str = "none"
    model: Optional[str] = None
    latency_ms: Optional[int] = None
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Prompt construction (grounding layer — the model only narrates these facts)
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = (
    "You are a senior mortgage Capital Markets risk analyst supporting a PennyMac "
    "Capital Markets Risk Copilot proof of concept. You will be given a JSON block "
    "containing a user question, a parsed intent, and PRE-COMPUTED, TRUSTED metrics "
    "and driver tables derived directly from the underlying dataset. "
    "Rules:\n"
    "1. Use ONLY the numbers and facts given in the JSON. Never invent or estimate "
    "a number that is not present in the JSON.\n"
    "2. Write a concise, professional risk narrative in 3 short paragraphs: "
    "(a) an executive-style summary directly answering the question, "
    "(b) the key portfolio/risk drivers from the driver table, "
    "(c) a risk conclusion referencing any threshold or limit-utilization concerns.\n"
    "3. Prefer plain business language over jargon; spell out DV01, CPR, PSA, MSR, "
    "Prepay01 briefly the first time you use them.\n"
    "4. If the JSON context looks insufficient to answer the question, say so "
    "explicitly rather than guessing.\n"
    "5. Return your three paragraphs as plain text separated by a single blank line. "
    "Do not restate or dump the raw JSON."
)


def build_user_content(payload: CopilotRequest) -> str:
    context = {
        "question": payload.question or "(no question provided — general portfolio review)",
        "intent": payload.intent,
        "metrics": payload.metrics,
        "top_drivers": payload.drivers[:7],
        "sample_records": payload.sample_records[:6],
    }
    return "Context JSON:\n" + json.dumps(context, indent=2, default=str)


def split_into_paragraphs(text: str) -> Dict[str, str]:
    parts = [p.strip() for p in text.strip().split("\n\n") if p.strip()]
    if not parts:
        parts = [text.strip()]
    summary = parts[0] if len(parts) > 0 else ""
    drivers = parts[1] if len(parts) > 1 else ""
    conclusion = parts[2] if len(parts) > 2 else ""
    if len(parts) > 3:
        conclusion = " ".join(parts[2:])
    return {"summary": summary, "drivers": drivers, "conclusion": conclusion}


def fmt_usd(v: Any) -> str:
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "$0"
    sign = "-" if v < 0 else ""
    return f"{sign}${abs(v):,.0f}"


def html_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


# ---------------------------------------------------------------------------
# Model backends
# ---------------------------------------------------------------------------
def call_mistral(system_prompt: str, user_content: str) -> Dict[str, Any]:
    key = os.environ["MISTRAL_API_KEY"]
    model = os.environ.get("MISTRAL_MODEL", "mistral-small-latest")
    base_url = os.environ.get("MISTRAL_BASE_URL", "https://api.mistral.ai/v1").rstrip("/")
    url = f"{base_url}/chat/completions"
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        "temperature": 0.3,
        "max_tokens": 700,
    }
    resp = httpx.post(url, headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"}, json=body, timeout=20.0)
    resp.raise_for_status()
    data = resp.json()
    content = data["choices"][0]["message"]["content"]
    if isinstance(content, list):
        text = "".join(
            chunk.get("text", "")
            for chunk in content
            if isinstance(chunk, dict) and chunk.get("type") == "text"
        )
    else:
        text = str(content)
    return {"text": text, "model": model}


def call_mock(payload: CopilotRequest) -> Dict[str, Any]:
    """
    Deterministic, input-dependent placeholder so the end-to-end wiring can be
    demonstrated and tested without any real API key. Clearly labeled as mock
    in the returned `source` field — the front end shows this in its badge.
    """
    m = payload.metrics or {}
    q = payload.question.strip() or "a general portfolio risk review"
    focus = (payload.intent or {}).get("focus", "overview")
    rows = m.get("rows", 0)
    upb = m.get("upb", 0)
    net_dv01 = m.get("netDv01", 0)
    prepay01 = m.get("prepay01", 0)
    top_driver = payload.drivers[0]["component"] if payload.drivers else "N/A"

    summary = (
        f"[MOCK LLM — configure MISTRAL_API_KEY for a real model] "
        f"Responding to \"{q}\" with a {focus}-focused view: the scoped population has "
        f"{rows:,} records and {fmt_usd(upb)} of current UPB, with net DV01 after hedge of "
        f"{fmt_usd(net_dv01)} and total Prepay01 of {fmt_usd(prepay01)}."
    )
    drivers = f"The leading portfolio component in this slice is {top_driver}, consistent with the driver table below."
    conclusion = (
        "This mock response proves the browser-to-backend round trip is wired correctly. "
        "Set MISTRAL_API_KEY in your environment to "
        "replace this with a genuine model-generated narrative."
    )
    return {"text": summary + "\n\n" + drivers + "\n\n" + conclusion, "model": "mock-engine-v1"}


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------
@app.post("/api/copilot", response_model=CopilotResponse)
def copilot(payload: CopilotRequest):
    start = time.time()
    force_mode = os.environ.get("COPILOT_FORCE_MODE", "").strip().lower()

    has_mistral = bool(os.environ.get("MISTRAL_API_KEY"))

    system_prompt = SYSTEM_PROMPT
    user_content = build_user_content(payload)

    try:
        if force_mode == "mock":
            result = call_mock(payload)
            source = "mock"
        elif has_mistral:
            result = call_mistral(system_prompt, user_content)
            source = "mistral"
        else:
            result = call_mock(payload)
            source = "mock"
    except Exception as exc:  # noqa: BLE001 - surface any backend failure as a graceful fallback
        result = call_mock(payload)
        source = "mock_after_error"
        result["text"] = f"[Live model call failed: {exc}]\n\n" + result["text"]

    parts = split_into_paragraphs(result["text"])
    latency_ms = int((time.time() - start) * 1000)

    return CopilotResponse(
        narrative_html=html_escape(parts["summary"]),
        drivers_html=html_escape(parts["drivers"]) if parts["drivers"] else None,
        conclusion_html=html_escape(parts["conclusion"]) if parts["conclusion"] else None,
        source=source,
        model=result.get("model"),
        latency_ms=latency_ms,
    )


@app.get("/api/health")
def health():
    mode = "mistral" if os.environ.get("MISTRAL_API_KEY") else "mock"
    return {"status": "ok", "configured_mode": mode}


# ---------------------------------------------------------------------------
# Static file serving (front end) — mounted LAST so /api/* routes above win
# ---------------------------------------------------------------------------
app.mount("/", StaticFiles(directory=APP_DIR, html=True), name="static")


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", "8787"))
    print(f"\nPennyMac Risk Copilot PoC backend starting on http://127.0.0.1:{port}\n")
    uvicorn.run(app, host="127.0.0.1", port=port)
