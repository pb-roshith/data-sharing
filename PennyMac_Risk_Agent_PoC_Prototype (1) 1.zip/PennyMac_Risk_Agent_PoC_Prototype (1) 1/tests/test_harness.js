// Minimal DOM stub to smoke-test app.js logic end-to-end without a real browser.
'use strict';
const fs = require('fs');
const vm = require('vm');

function FakeEl(tag) {
  this.tag = tag;
  this._html = '';
  this.value = '';
  this.textContent = '';
  this._listeners = {};
  this._attrs = {};
}
Object.defineProperty(FakeEl.prototype, 'innerHTML', {
  get: function () { return this._html; },
  set: function (v) { this._html = v; }
});
FakeEl.prototype.addEventListener = function (ev, cb) {
  this._listeners[ev] = this._listeners[ev] || [];
  this._listeners[ev].push(cb);
};
FakeEl.prototype.appendChild = function (el) { return el; };
FakeEl.prototype.setAttribute = function (n, v) { this._attrs[n] = v; };
FakeEl.prototype.getAttribute = function (n) { return this._attrs[n]; };
FakeEl.prototype.querySelectorAll = function (sel) {
  // Cache per (selector, current html) so repeated calls without an intervening
  // innerHTML change return the SAME element instances (mirrors real DOM semantics
  // closely enough: listeners attached in one call are visible to a later call).
  if (this._qsCacheHtml === this._html && this._qsCacheSel === sel && this._qsCache) {
    return this._qsCache;
  }
  var out = [];
  if (sel === '.tab') {
    var re = /data-tab="([^"]+)"/g;
    var m;
    while ((m = re.exec(this._html))) {
      (function (tabId) {
        var btn = new FakeEl('button');
        btn.getAttribute = function (n) { return n === 'data-tab' ? tabId : null; };
        out.push(btn);
      })(m[1]);
    }
  }
  this._qsCacheHtml = this._html;
  this._qsCacheSel = sel;
  this._qsCache = out;
  return out;
};

var elements = {};
function getEl(id) { if (!elements[id]) elements[id] = new FakeEl('div'); return elements[id]; }

var fakeDocument = {
  getElementById: getEl,
  createElement: function (tag) { return new FakeEl(tag); },
  body: { appendChild: function () {}, removeChild: function () {} },
  readyState: 'complete',
  addEventListener: function () {}
};

// Load real data.js content (contains window.POC_* assignments)
var dataJs = fs.readFileSync(__dirname + '/../data.js', 'utf8');
var appJs = fs.readFileSync(__dirname + '/../app.js', 'utf8');

var sandbox = {
  window: {},
  document: fakeDocument,
  console: console,
  Intl: Intl,
  Blob: function () {},
  URL: { createObjectURL: function () { return 'blob:fake'; }, revokeObjectURL: function () {} }
};
sandbox.window.document = fakeDocument;
vm.createContext(sandbox);

vm.runInContext(dataJs, sandbox, { filename: 'data.js' });
console.log('Loaded data: rows=' + sandbox.window.POC_DATA.length + ' meta=' + JSON.stringify(sandbox.window.POC_META));

vm.runInContext(appJs, sandbox, { filename: 'app.js' });
console.log('app.js executed (init ran via readyState=complete)');

// ---- Simulate UI interactions ----
function fire(id, event) {
  var el = elements[id];
  var cbs = el._listeners[event] || [];
  cbs.forEach(function (cb) { cb({ currentTarget: el, key: '', ctrlKey: false, metaKey: false }); });
}

// Check meta/pill got populated
console.log('metaLine:', elements['metaLine'].textContent);
console.log('recordPill:', elements['recordPill'].textContent);
console.assert(elements['metaLine'].textContent.indexOf('20000') !== -1 || elements['metaLine'].textContent.indexOf('rows') !== -1, 'metaLine should mention rows');

// Default tab (copilot) should have rendered a non-trivial report
var mainHtml = elements['mainArea'].innerHTML;
console.log('Initial mainArea length:', mainHtml.length);
console.assert(mainHtml.length > 500, 'Copilot report should render substantial HTML by default');
console.assert(mainHtml.indexOf('Risk Copilot Report') !== -1, 'Report title missing');
console.assert(mainHtml.indexOf('Executive Summary') !== -1, 'Executive Summary section missing');
console.assert(mainHtml.indexOf('Risk Scorecard') !== -1, 'Risk Scorecard section missing');
console.assert(mainHtml.indexOf('<svg') !== -1, 'Expected at least one SVG chart in report');

// Click "Generate Report" button directly
fire('generateBtn', 'click');
console.assert(elements['mainArea'].innerHTML.length > 500, 'Generate Report click should re-render report');
console.log('Generate Report button: OK, output length=', elements['mainArea'].innerHTML.length);

// Click quick-question buttons
['quickPrepay', 'quickDv01', 'quickFunding', 'quickExec'].forEach(function (btnId) {
  fire(btnId, 'click');
  var len = elements['mainArea'].innerHTML.length;
  var askVal = elements['askInput'].value;
  console.log(btnId + ' -> askInput="' + askVal + '" reportLen=' + len);
  console.assert(len > 500, btnId + ' should produce a populated report');
  console.assert(askVal.length > 0, btnId + ' should set a question');
});

// Switch through all other tabs
var tabIds = ['exec', 'market', 'prepay', 'funding', 'servicing', 'dictionary', 'copilot'];
tabIds.forEach(function (tabId) {
  var btns = elements['tabbar'].querySelectorAll('.tab');
  var target = null;
  for (var i = 0; i < btns.length; i++) { if (btns[i].getAttribute('data-tab') === tabId) { target = btns[i]; break; } }
  if (!target) { console.log('WARN: tab button not found for', tabId); return; }
  var cbs = elements['tabbar']._listeners['click'] || [];
  // tabbar click listeners are attached per-button in renderTabs via querySelectorAll each render,
  // so instead directly find and click via the individual button's own listeners:
  var btnListeners = target._listeners['click'] || [];
  btnListeners.forEach(function (cb) { cb({ currentTarget: target }); });
  var out = elements['mainArea'].innerHTML;
  console.log('Tab "' + tabId + '" rendered, length=' + out.length);
  console.assert(out.length > 50, 'Tab ' + tabId + ' should render content');
});

// Apply filters then reset
// (Real <select> elements default their .value to the first <option>, which is "All".
//  Our lightweight stub doesn't parse <option> tags, so we set the other selects to
//  "All" explicitly here to mirror real default browser behavior before changing fSegment.)
elements['fComponent'].value = 'All';
elements['fProduct'].value = 'All';
elements['fAgency'].value = 'All';
elements['fSegment'].value = 'Servicing';
fire('applyBtn', 'click');
console.log('After filter Segment=Servicing, recordPill:', elements['recordPill'].textContent);
console.assert(elements['recordPill'].textContent.indexOf('of') !== -1, 'Filtered pill should show "X of Y"');

fire('resetBtn', 'click');
console.log('After reset, recordPill:', elements['recordPill'].textContent);

console.log('\n=== ALL SMOKE TESTS PASSED (no exceptions thrown) ===');
