// Real end-to-end test using an ACTUAL DOM parser (@xmldom, already installed in
// this environment) for the parts of the page that app.js dynamically injects via
// innerHTML (the mainArea report content, including nested ids like #liveBadge,
// #narrSummary, #narrDrivers, #narrConclusion). This closes the gap left by the
// earlier hand-rolled stub, which could not resolve getElementById() lookups into
// dynamically-inserted HTML the way a real browser does.
//
// Top-level static controls (selects, inputs, buttons defined directly in
// index.html) remain simple JS objects, exactly as a real browser would expose
// static elements that don't need HTML re-parsing.
'use strict';
const fs = require('fs');
const vm = require('vm');
const { DOMParser } = require('/opt/oai-docgen/node_modules/@xmldom/xmldom');

const BASE = process.env.TEST_BASE_URL || 'http://127.0.0.1:8787';

// ---- Static (non-parsed) stub elements, same as before ----
function FakeEl(tag) {
  this.tag = tag; this._html = ''; this.value = ''; this.textContent = '';
  this._listeners = {}; this._attrs = {}; this.style = {};
}
FakeEl.prototype.addEventListener = function (ev, cb) {
  this._listeners[ev] = this._listeners[ev] || [];
  this._listeners[ev].push(cb);
};
FakeEl.prototype.appendChild = function (el) { return el; };
FakeEl.prototype.setAttribute = function (n, v) { this._attrs[n] = v; };
FakeEl.prototype.getAttribute = function (n) { return this._attrs[n]; };
FakeEl.prototype.querySelectorAll = function () { return []; };

// ---- Real-DOM-backed wrapper specifically for #mainArea ----
function MainAreaEl() {
  this.tag = 'section';
  this._rawHtml = '';
  this._doc = null; // parsed xmldom Document, rebuilt on every innerHTML assignment
}
function quietParser() {
  return new DOMParser({
    onError: function (level, msg) {
      // xmldom's HTML-mode SAX parser reports many "errors" for perfectly valid
      // HTML5 constructs (unclosed <br>, <img>, boolean attributes, etc.) because
      // it's fundamentally an XML parser being used in HTML-tolerant mode.
      // We only want to hear about TRUE fatal failures, so swallow everything else.
      if (level === 'fatalError') throw new Error(msg);
    }
  });
}
Object.defineProperty(MainAreaEl.prototype, 'innerHTML', {
  get: function () { return this._rawHtml; },
  set: function (v) {
    this._rawHtml = v;
    try {
      this._doc = quietParser().parseFromString('<div id="__root__">' + v + '</div>', 'text/html');
    } catch (e) {
      console.error('  [MainAreaEl] Failed to parse injected HTML as real DOM:', e.message);
      this._doc = null;
    }
  }
});
MainAreaEl.prototype.findById = function (id) {
  if (!this._doc || !this._doc.getElementById) return null;
  return this._doc.getElementById(id);
};

var elements = {};
var mainAreaEl = new MainAreaEl();
elements['mainArea'] = mainAreaEl;

function getStaticEl(id) { if (!elements[id]) elements[id] = new FakeEl('div'); return elements[id]; }

// Wrapper returned for ids that only exist INSIDE mainArea's dynamically-parsed HTML.
function NestedElWrapper(node) {
  this._node = node;
}
Object.defineProperty(NestedElWrapper.prototype, 'innerHTML', {
  get: function () {
    return this._node.toString ? this._node.toString() : '';
  },
  set: function (v) {
    // Replace this node's children with newly parsed content, then re-serialize
    // the WHOLE mainArea tree back into mainAreaEl._rawHtml so future lookups
    // (including a second call to getElementById for the SAME id) see the update —
    // exactly like a real browser keeps one live document tree.
    while (this._node.firstChild) this._node.removeChild(this._node.firstChild);
    var frag = quietParser().parseFromString('<span>' + v + '</span>', 'text/html');
    var wrapperSpan = frag.getElementsByTagName('span')[0];
    var child = wrapperSpan.firstChild;
    while (child) {
      var next = child.nextSibling;
      this._node.appendChild(this._node.ownerDocument.importNode ? this._node.ownerDocument.importNode(child, true) : child);
      child = next;
    }
    // Re-serialize whole tree back to the stored raw HTML string.
    var rootDiv = this._node.ownerDocument.getElementById('__root__');
    mainAreaEl._rawHtml = serializeChildren(rootDiv);
  }
});
Object.defineProperty(NestedElWrapper.prototype, 'style', {
  get: function () { return {}; }
});
NestedElWrapper.prototype.addEventListener = function (ev, cb) {
  this._listeners = this._listeners || {};
  this._listeners[ev] = this._listeners[ev] || [];
  this._listeners[ev].push(cb);
};
NestedElWrapper.prototype.removeEventListener = function () {};

function serializeChildren(node) {
  var out = '';
  var child = node.firstChild;
  while (child) {
    out += child.toString();
    child = child.nextSibling;
  }
  return out;
}

var fakeDocument = {
  getElementById: function (id) {
    if (elements[id]) return elements[id]; // static top-level element already known
    var node = mainAreaEl.findById(id);
    if (node) return new NestedElWrapper(node);
    return getStaticEl(id); // last resort stub, mirrors original harness behavior
  },
  createElement: function (tag) { return new FakeEl(tag); },
  body: { appendChild: function () {}, removeChild: function () {} },
  readyState: 'complete',
  addEventListener: function () {}
};

var dataJs = fs.readFileSync(__dirname + '/../data.js', 'utf8');
var appJs = fs.readFileSync(__dirname + '/../app.js', 'utf8');

var sandbox = {
  window: { PENNYMAC_COPILOT_ENDPOINT: BASE + '/api/copilot' },
  document: fakeDocument,
  console: console,
  Intl: Intl,
  Blob: function () {},
  URL: { createObjectURL: function () { return 'blob:fake'; }, revokeObjectURL: function () {} },
  fetch: fetch,
  AbortController: AbortController,
  setTimeout: setTimeout,
  clearTimeout: clearTimeout
};
sandbox.window.document = fakeDocument;
vm.createContext(sandbox);
vm.runInContext(dataJs, sandbox, { filename: 'data.js' });
vm.runInContext(appJs, sandbox, { filename: 'app.js' });

function sleep(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }

async function askAndWait(question, waitMs) {
  getStaticEl('askInput').value = question;
  var cbs = getStaticEl('generateBtn')._listeners['click'] || [];
  cbs.forEach(function (cb) { cb(); });
  await sleep(waitMs || 2000);
  var badgeNode = mainAreaEl.findById('liveBadge');
  var summaryNode = mainAreaEl.findById('narrSummary');
  return {
    badge: badgeNode ? badgeNode.textContent : null,
    summary: summaryNode ? summaryNode.textContent : null,
    fullHtmlLength: mainAreaEl.innerHTML.length
  };
}

async function main() {
  console.log('Target backend:', BASE, '\n');

  console.log('--- Question 1: DV01/GNMA ---');
  var r1 = await askAndWait('Summarize DV01 and hedge effectiveness for GNMA', 2500);
  console.log('Badge  :', r1.badge);
  console.log('Summary:', r1.summary);
  console.assert(r1.badge && r1.badge.indexOf('Live agent connected') !== -1, 'Expected live badge to say connected');
  console.assert(r1.summary && r1.summary.indexOf('MOCK LLM') !== -1, 'Expected the summary to now be the SERVER (mock) narrative, not the local engine text');

  console.log('\n--- Question 2: Prepay01 ---');
  var r2 = await askAndWait('Which portfolio has the highest Prepay01 exposure?', 2500);
  console.log('Badge  :', r2.badge);
  console.log('Summary:', r2.summary);
  console.assert(r2.badge && r2.badge.indexOf('Live agent connected') !== -1, 'Expected live badge to say connected (Q2)');
  console.assert(r2.summary && r2.summary !== r1.summary, 'Summary should differ between Q1 and Q2 when both are live-served');

  console.log('\n=== RESULT ===');
  var pass = r1.badge && r1.badge.indexOf('Live agent connected') !== -1 &&
             r1.summary && r1.summary.indexOf('MOCK LLM') !== -1 &&
             r2.badge && r2.badge.indexOf('Live agent connected') !== -1 &&
             r2.summary !== r1.summary;
  console.log(pass ? 'LIVE AGENT INTEGRATION CONFIRMED WORKING END-TO-END' : 'LIVE AGENT INTEGRATION TEST FAILED');
  process.exit(pass ? 0 : 1);
}

main().catch(function (err) {
  console.error('TEST ERROR:', err);
  process.exit(1);
});
