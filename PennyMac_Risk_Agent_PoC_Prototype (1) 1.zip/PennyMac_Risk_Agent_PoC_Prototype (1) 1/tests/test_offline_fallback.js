// Verifies the OFFLINE fallback path: when no backend is reachable, the app
// must (a) show "Live agent offline" (never hang, never show a broken UI),
// and (b) still produce genuinely DIFFERENT narratives/content for different
// questions using the built-in local analyst engine (this is what fixes the
// original "same chart/verbiage regardless of question" complaint even with
// zero backend configured).
'use strict';
const fs = require('fs');
const vm = require('vm');
const { DOMParser } = require('/opt/oai-docgen/node_modules/@xmldom/xmldom');

// Deliberately point at a port nothing is listening on, to force the fallback
// path deterministically regardless of whether a dev server happens to be up.
const DEAD_ENDPOINT = 'http://127.0.0.1:1/api/copilot';

function FakeEl(tag) {
  this.tag = tag; this.value = ''; this.textContent = ''; this._listeners = {}; this._attrs = {}; this.style = {};
}
FakeEl.prototype.addEventListener = function (ev, cb) { this._listeners[ev] = this._listeners[ev] || []; this._listeners[ev].push(cb); };
FakeEl.prototype.appendChild = function (el) { return el; };
FakeEl.prototype.setAttribute = function (n, v) { this._attrs[n] = v; };
FakeEl.prototype.getAttribute = function (n) { return this._attrs[n]; };
FakeEl.prototype.querySelectorAll = function () { return []; };

function MainAreaEl() { this.tag = 'section'; this._rawHtml = ''; this._doc = null; }
function quietParser() {
  return new DOMParser({ onError: function (level, msg) { if (level === 'fatalError') throw new Error(msg); } });
}
Object.defineProperty(MainAreaEl.prototype, 'innerHTML', {
  get: function () { return this._rawHtml; },
  set: function (v) {
    this._rawHtml = v;
    try { this._doc = quietParser().parseFromString('<div id="__root__">' + v + '</div>', 'text/html'); }
    catch (e) { this._doc = null; }
  }
});
MainAreaEl.prototype.findById = function (id) { return (this._doc && this._doc.getElementById) ? this._doc.getElementById(id) : null; };

var elements = {};
var mainAreaEl = new MainAreaEl();
elements['mainArea'] = mainAreaEl;
function getStaticEl(id) { if (!elements[id]) elements[id] = new FakeEl('div'); return elements[id]; }

function NestedElWrapper(node) { this._node = node; }
Object.defineProperty(NestedElWrapper.prototype, 'innerHTML', {
  get: function () { return this._node.toString(); },
  set: function (v) {
    // Faithfully mutate the real parsed tree (mirrors real browser innerHTML
    // assignment), then re-serialize the whole mainArea tree back into the
    // stored raw HTML string so subsequent getElementById lookups (including
    // repeat lookups for this same id) see the update — exactly like a real
    // browser keeps one single live document.
    while (this._node.firstChild) this._node.removeChild(this._node.firstChild);
    var frag = quietParser().parseFromString('<span>' + v + '</span>', 'text/html');
    var wrapperSpan = frag.getElementsByTagName('span')[0];
    var child = wrapperSpan.firstChild;
    while (child) {
      var next = child.nextSibling;
      this._node.appendChild(child);
      child = next;
    }
    var rootDiv = mainAreaEl._doc.getElementById('__root__');
    var out = '';
    var c = rootDiv.firstChild;
    while (c) { out += c.toString(); c = c.nextSibling; }
    mainAreaEl._rawHtml = out;
  }
});
NestedElWrapper.prototype.addEventListener = function () {};

var fakeDocument = {
  getElementById: function (id) {
    if (elements[id]) return elements[id];
    var node = mainAreaEl.findById(id);
    if (node) return new NestedElWrapper(node);
    return getStaticEl(id);
  },
  createElement: function (tag) { return new FakeEl(tag); },
  body: { appendChild: function () {}, removeChild: function () {} },
  readyState: 'complete',
  addEventListener: function () {}
};

var dataJs = fs.readFileSync(__dirname + '/../data.js', 'utf8');
var appJs = fs.readFileSync(__dirname + '/../app.js', 'utf8');
var sandbox = {
  window: { PENNYMAC_COPILOT_ENDPOINT: DEAD_ENDPOINT },
  document: fakeDocument, console: console, Intl: Intl,
  Blob: function () {}, URL: { createObjectURL: function () { return 'x'; }, revokeObjectURL: function () {} },
  fetch: fetch, AbortController: AbortController, setTimeout: setTimeout, clearTimeout: clearTimeout
};
sandbox.window.document = fakeDocument;
vm.createContext(sandbox);
vm.runInContext(dataJs, sandbox, { filename: 'data.js' });
vm.runInContext(appJs, sandbox, { filename: 'app.js' });

function sleep(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }

async function ask(question) {
  getStaticEl('askInput').value = question;
  (getStaticEl('generateBtn')._listeners['click'] || []).forEach(function (cb) { cb(); });
  // NOTE: full report generation over 20,000 rows takes ~650-800ms of synchronous
  // JS compute (measured separately), plus the dead-endpoint fetch needs a moment
  // to fail. 2000ms gives a safe margin for both in this sandboxed environment.
  await sleep(2000);
  var badgeNode = mainAreaEl.findById('liveBadge');
  var summaryNode = mainAreaEl.findById('narrSummary');
  var focusChip = /Focus: (\w+)/.exec(mainAreaEl.innerHTML);
  return {
    badge: badgeNode ? badgeNode.textContent : null,
    summary: summaryNode ? summaryNode.textContent : null,
    focus: focusChip ? focusChip[1] : null,
    recordCountLine: (/(\d[\d,]*) records/.exec(mainAreaEl.innerHTML) || [])[1]
  };
}

async function main() {
  var questions = [
    'Generate an executive summary of overall portfolio risk',
    'Summarize DV01 and hedge effectiveness for GNMA',
    'Generate a report on Prepay01, CPR gap and MSR value impact',
    'Identify funding, warehouse and liquidity pressure points',
    'Show delinquency and production risk for the servicing book'
  ];
  var results = [];
  for (var i = 0; i < questions.length; i++) {
    var r = await ask(questions[i]);
    console.log('\nQ' + (i + 1) + ': ' + questions[i]);
    console.log('  badge  :', r.badge);
    console.log('  focus  :', r.focus);
    console.log('  records:', r.recordCountLine);
    console.log('  summary:', (r.summary || '').slice(0, 160) + '...');
    results.push(r);
  }

  var allOffline = results.every(function (r) { return r.badge && r.badge.indexOf('offline') !== -1; });
  var focuses = results.map(function (r) { return r.focus; });
  var uniqueFocuses = focuses.filter(function (v, i) { return focuses.indexOf(v) === i; });
  var summaries = results.map(function (r) { return r.summary; });
  var uniqueSummaries = summaries.filter(function (v, i) { return summaries.indexOf(v) === i; });

  console.log('\n=== SUMMARY ===');
  console.log('All badges show offline (expected, dead endpoint):', allOffline);
  console.log('Distinct focus areas detected across 5 questions:', uniqueFocuses.join(', '), '(' + uniqueFocuses.length + ' unique)');
  console.log('Distinct narrative summaries across 5 questions:', uniqueSummaries.length, 'of', summaries.length);

  var pass = allOffline && uniqueFocuses.length >= 4 && uniqueSummaries.length === summaries.length;
  console.log(pass ? '\nPASS: offline fallback is question-aware and non-static' : '\nFAIL');
  process.exit(pass ? 0 : 1);
}

main().catch(function (e) { console.error('ERROR', e); process.exit(1); });
