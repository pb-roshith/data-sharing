"""
Tests for server.py's /api/copilot logic, run entirely in-process via
FastAPI's TestClient — no real network calls, no real API keys needed.
Covers: mock mode, forced modes, error->fallback behavior, and the
health endpoint's mode detection.
"""
import os
import sys
import json

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

# Ensure a clean slate: no real credentials should leak in from the shell env
for k in ["MISTRAL_API_KEY", "MISTRAL_MODEL", "MISTRAL_BASE_URL", "COPILOT_FORCE_MODE"]:
    os.environ.pop(k, None)
os.environ["COPILOT_SKIP_DOTENV"] = "1"

from fastapi.testclient import TestClient
import server as srv

client = TestClient(srv.app)

SAMPLE_PAYLOAD = {
    "question": "Generate a report on Prepay01, CPR gap and MSR value impact",
    "intent": {"focus": "prepay", "agency": None, "product": None, "component": None},
    "metrics": {
        "rows": 4213, "upb": 812345678, "netDv01": -102345, "prepay01": -543210,
        "cpr": 0.14, "mcpr": 0.11, "cprGap": 0.03, "whUtil": 0.62, "dvUtil": 0.55,
        "prepayUtil": 0.71, "eboCount": 12, "defectCount": 3
    },
    "drivers": [
        {"component": "Owned MSR servicing", "current_upb_usd": 400000000, "net_dv01_after_hedge": -50000,
         "prepay01_usd": -300000, "current_cpr_pct": 0.16, "cpr_gap_pct": 0.04, "warehouse_utilization_pct": 0},
        {"component": "Correspondent production", "current_upb_usd": 200000000, "net_dv01_after_hedge": -20000,
         "prepay01_usd": -50000, "current_cpr_pct": 0.08, "cpr_gap_pct": 0.01, "warehouse_utilization_pct": 0.7},
    ],
    "sample_records": [
        {"record_id": "PFSI-POC-00001", "portfolio_component": "Owned MSR servicing", "current_upb_usd": 500000}
    ]
}


def test_health_defaults_to_mock():
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body["configured_mode"] == "mock", body
    print("test_health_defaults_to_mock: PASS ->", body)


def test_copilot_mock_mode_end_to_end():
    r = client.post("/api/copilot", json=SAMPLE_PAYLOAD)
    assert r.status_code == 200, r.text
    body = r.json()
    print("test_copilot_mock_mode_end_to_end response:", json.dumps(body, indent=2))
    assert body["source"] == "mock"
    assert body["narrative_html"] is not None
    assert "MOCK LLM" in body["narrative_html"]
    # Must reference numbers actually present in the payload (grounding check)
    assert "4,213" in body["narrative_html"] or "4213" in body["narrative_html"]
    print("test_copilot_mock_mode_end_to_end: PASS")


def test_copilot_reflects_different_questions():
    """Two different metric payloads must yield two different mock narratives —
    proving output is NOT static regardless of what is asked."""
    payload_a = json.loads(json.dumps(SAMPLE_PAYLOAD))
    payload_b = json.loads(json.dumps(SAMPLE_PAYLOAD))
    payload_b["question"] = "Summarize DV01 and hedge effectiveness for GNMA"
    payload_b["intent"]["focus"] = "market"
    payload_b["metrics"]["rows"] = 999
    payload_b["metrics"]["upb"] = 111222333
    payload_b["metrics"]["netDv01"] = 87654
    payload_b["drivers"][0]["component"] = "Correspondent production"

    ra = client.post("/api/copilot", json=payload_a).json()
    rb = client.post("/api/copilot", json=payload_b).json()

    assert ra["narrative_html"] != rb["narrative_html"], "Narratives should differ when inputs differ!"
    assert "999" in rb["narrative_html"]
    assert "111,222,333" in rb["narrative_html"] or "111222333" in rb["narrative_html"]
    print("test_copilot_reflects_different_questions: PASS")
    print("  A:", ra["narrative_html"][:120], "...")
    print("  B:", rb["narrative_html"][:120], "...")


def test_forced_mock_mode_env_var():
    os.environ["COPILOT_FORCE_MODE"] = "mock"
    try:
        r = client.post("/api/copilot", json=SAMPLE_PAYLOAD)
        body = r.json()
        assert body["source"] == "mock"
        print("test_forced_mock_mode_env_var: PASS")
    finally:
        os.environ.pop("COPILOT_FORCE_MODE", None)


def test_mistral_path_falls_back_gracefully_on_bad_credentials():
    """Point at a real-shaped-but-invalid Mistral endpoint; confirm the server
    catches the failure and still returns a usable (fallback) response
    instead of crashing or hanging indefinitely."""
    os.environ["MISTRAL_BASE_URL"] = "http://127.0.0.1:1/v1"
    os.environ["MISTRAL_API_KEY"] = "fake-key-for-test"
    try:
        r = client.post("/api/copilot", json=SAMPLE_PAYLOAD)
        assert r.status_code == 200
        body = r.json()
        print("test_mistral_path_falls_back_gracefully_on_bad_credentials:", body["source"])
        assert body["source"] == "mock_after_error"
        assert body["narrative_html"] is not None
        print("test_mistral_path_falls_back_gracefully_on_bad_credentials: PASS")
    finally:
        for k in ["MISTRAL_BASE_URL", "MISTRAL_API_KEY"]:
            os.environ.pop(k, None)


def test_health_reflects_configured_mode():
    os.environ["MISTRAL_API_KEY"] = "fake-key-for-test"
    try:
        r = client.get("/api/health")
        assert r.json()["configured_mode"] == "mistral"
        print("test_health_reflects_configured_mode: PASS")
    finally:
        os.environ.pop("MISTRAL_API_KEY", None)


def test_static_index_served():
    r = client.get("/")
    assert r.status_code == 200
    assert b"PennyMac" in r.content
    print("test_static_index_served: PASS")


def test_static_app_js_served():
    r = client.get("/app.js")
    assert r.status_code == 200
    assert b"parseIntent" in r.content
    print("test_static_app_js_served: PASS")


if __name__ == "__main__":
    tests = [
        test_health_defaults_to_mock,
        test_copilot_mock_mode_end_to_end,
        test_copilot_reflects_different_questions,
        test_forced_mock_mode_env_var,
        test_mistral_path_falls_back_gracefully_on_bad_credentials,
        test_health_reflects_configured_mode,
        test_static_index_served,
        test_static_app_js_served,
    ]
    failed = 0
    for t in tests:
        try:
            t()
        except AssertionError as e:
            failed += 1
            print(f"FAILED: {t.__name__} -> {e}")
        except Exception as e:
            failed += 1
            print(f"ERROR in {t.__name__}: {type(e).__name__}: {e}")
    print("\n" + ("=" * 60))
    if failed:
        print(f"{failed} test(s) FAILED")
        sys.exit(1)
    else:
        print("ALL SERVER TESTS PASSED")
